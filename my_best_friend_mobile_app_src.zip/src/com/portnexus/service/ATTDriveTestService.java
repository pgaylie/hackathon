package com.portnexus.service;

import java.net.URI;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.X509TrustManager;

import com.portnexus.websocket.WebSocketClient;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Log;

public class ATTDriveTestService  extends Service {
	public String WEBSOCKET_PROD_URL = "wss://barnyard.mobileassociate.com:443/spsedictation/safecomm";
	String websocketUrl = null;
	
    WebSocketClient webSocketclient;  // The websocket client
    ReconnectSocketThread aReconnectSocketThread = new ReconnectSocketThread();  // This will reconnect the socket if the connection drops
	PingSocketThread aPingSocketThread = new PingSocketThread();

	ATTDriveTestService me = this;
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	 public int onStartCommand(Intent intent, int flags, int startId) {
		// Start ping and reconnect
		aReconnectSocketThread.start();  // This will also do the initial connect to the websocket
		aPingSocketThread.start();

		
		return START_STICKY;		
	 }	
	
	/*
	 * createWebSocket
	 * Create the web socket
	 */
	public void connectWebSocket() {
        log("connectWebSocket");
        
		// Setup the URL
        websocketUrl = WEBSOCKET_PROD_URL;
		
		log("Create Web Socket url=" + websocketUrl);
		
		// Create The web socket
		webSocketclient = new WebSocketClient(URI.create(websocketUrl), new WebSocketClient.Listener() {
		    @Override
		    public void onConnect() {
		        log("Socket Connected!");
		        
		        // Send the register command to the socket server
		        try {
		        	// Make sure that the phone number can be read
	        		// Keep retrying, if phone number is null
	        		int i = 0;
	        		String myPhoneNumber = getMyPhoneNumber();
	        		while (myPhoneNumber == null && i < 10) {
				        log("Phone number is null. Sleep and retry");
				        myPhoneNumber = getMyPhoneNumber() ;
				        Thread.sleep(10000);
				        i++;
	        		}
	        		if (myPhoneNumber != null) {
				        	log("Register Phone: " + myPhoneNumber);
			        		String registerCommand = String.format("<sc op='R'><phone>%s</phone><d>A</d></sc>", myPhoneNumber);
			        		webSocketclient.send(registerCommand);
					        log("Socket is Registered");
					        
					        // Register interest in dog loc
					        registerInterestInDogLocation();
					        registerInterestInDogLost();
					        
					        // TESt
					        //sendDogLocated();
	        		} else {
				        log("Did not register. Phone is null.");
	        		}
		        } catch(Exception ex) {
		        	log("onConnect Exception: " + ex.getMessage());
		        }
		    }

		    @Override
		    public void onMessage(String message) {
		        log(String.format("Got string message! %s", message));
		        
		        // Parse the dog message - dog is missing.
		        // This is received by the Crowd Source - start looking for dog.
		        if (message.contains("<doglost>")) {
		        	// Get the proximity of the dog.
		        	// Send a <dogloc> when proximity is found
		        } else if (message.contains("<dogloc>")) {
		        	// dog located. Diplay lat/lon
		        }
		        
		    }

		    @Override
		    public void onMessage(byte[] data) {
		        log(String.format("Got binary message! "));
		    }

		    @Override
		    public void onDisconnect(int code, String reason) {
		        log(String.format("Disconnected! Code: %d Reason: %s", code, reason));
		       
		        // Attempt to reconnect
		        webSocketclient = null;
		        synchronized(aReconnectSocketThread.connectLockObject){
			        aReconnectSocketThread.connectLockObject.notifyAll();
		        }
		    }

		    @Override
		    public void onError(Exception error) {
		        log("Error! " +  error.getMessage());
		        
		        //Attempt To reconnect
		        webSocketclient = null;
		        synchronized(aReconnectSocketThread.connectLockObject){
			        aReconnectSocketThread.connectLockObject.notifyAll();
		        }
		    }

		}, null);

		// Now connect the web socket
		log("Attempt to connect web socket");
		
		// Setup a trust manager that allows all certs
		X509TrustManager[] trustManagers = new X509TrustManager[]{new X509TrustManager(){ 
          public void checkClientTrusted(X509Certificate[] chain, 
                          String authType) throws CertificateException {} 
          public void checkServerTrusted(X509Certificate[] chain, 
                          String authType) throws CertificateException {} 
          public X509Certificate[] getAcceptedIssuers() { 
                  return new X509Certificate[0]; 
          }}};
          
		WebSocketClient.setTrustManagers(trustManagers);
		
		// Connect the socket
		if (webSocketclient != null)
			webSocketclient.connect();
	}
	
	
	public String getMyPhoneNumber() { 
		if (Build.MODEL.equals("SAMSUNG-SGH-I337")) {
			return "2145551111";
		} else {
			return "2145552222";
		}
	}


	public void log(String aString) {
			Log.i("ATTDriveTest", aString);		
	}
	
	// Owner sends this
	public void sendDogLost() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='doglost'>");
				sb.append("</sc>");
        				
				log("Dog Lost");
				
				webSocketclient.send(sb.toString());
				
			} catch(Exception ex) {
			}
		}
	}
	
	public void registerInterestInDogLocation() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='IC'><opcode>dogloc</opcode></sc>");
				webSocketclient.send(sb.toString());
				log("Dog Located registered");
			} catch(Exception ex) {
				log(ex.getMessage());
			}
		}
		
	}
	
	public void registerInterestInDogLost() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='IC'><opcode>doglost</opcode></sc>");
				webSocketclient.send(sb.toString());
				log("Dog Lost registered");
				
			} catch(Exception ex) {
				log(ex.getMessage());
			}
		}
		
	}
	
	public void sendDogLocated() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='dogloc'>");
				sb.append("<lat>").append("36.113932").append("</lat>");  
				sb.append("<lon>").append("-115.197266").append("</lon>");  
				sb.append("</sc>");
        				
				log("Dog Lost");
				
				webSocketclient.send(sb.toString());
				
			} catch(Exception ex) {
			}
		}

	}
		
	
	// Connect Web Socket Thread
	public  class ReconnectSocketThread extends Thread {
		public final Object connectLockObject = new Object();
		public boolean stopThread = false;
		   
		@Override 
		public void run() {
			// Do an initial sleep. While the phone is rebooting we need time so that the carrier connects
//			try {
//				Thread.sleep(120000);
//			} catch (InterruptedException e) {
//			}

			while (!stopThread) {
				// Wait until the websocket has become null.
				// After the socket becomes null then try to reconnected the web socket
				synchronized(connectLockObject){
				    while (webSocketclient != null){
				    	try {
							connectLockObject.wait();
						} catch (InterruptedException e) {
						}
				    }
				}
				
				// webSocket is null. Reconnect to the websocket
				try {
					if (!stopThread)
						me.connectWebSocket();
				} catch(Exception ex) {
				}
				
				// If the user is out of data coverage then we will get into a reconnect loop. So sleep for a while
				try {
					Thread.sleep(120000);
				} catch (InterruptedException e) {
				}
			}
		}
	}
	
	// Socket Ping Thread.
	// Ping the server.
	public  class PingSocketThread extends Thread {
		public boolean stopThread = false;
		
		@Override 
		public void run() {
			while (!stopThread) {
				if (webSocketclient != null && webSocketclient.isConnected()) {
					// Send the ping
					try {
						webSocketclient.send("<sc op='P'/>");
					} catch(Exception ex) {
						log("Socket ping Exception: " + ex.getMessage());
					}
				}
				try {
					Thread.sleep(240000);
				} catch(Exception ex) {
				}
			}
		}
	}



}
