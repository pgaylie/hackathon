/**
 * Copyright (C) 2014 Gimbal, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of Gimbal, Inc.
 *
 * The following sample code illustrates various aspects of the Gimbal SDK.
 *
 * The sample code herein is provided for your convenience, and has not been
 * tested or designed to work on any particular system configuration. It is
 * provided AS IS and your use of this sample code, whether as provided or
 * with any modification, is at your own risk. Neither Gimbal, Inc.
 * nor any affiliate takes any liability nor responsibility with respect
 * to the sample code, and disclaims all warranties, express and
 * implied, including without limitation warranties on merchantability,
 * fitness for a specified purpose, and against infringement.
 */
package com.portnexus.proximity;

import java.net.URI;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;

import javax.net.ssl.X509TrustManager;

import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import com.gimbal.android.Communication;
import com.gimbal.android.CommunicationListener;
import com.gimbal.android.CommunicationManager;
import com.gimbal.android.Gimbal;
import com.gimbal.android.Place;
import com.gimbal.android.PlaceEventListener;
import com.gimbal.android.PlaceManager;
import com.portnexus.proximity.GimbalEvent.TYPE;
import com.portnexus.service.ATTDriveTestService;
import com.portnexus.service.ATTDriveTestService.PingSocketThread;
import com.portnexus.service.ATTDriveTestService.ReconnectSocketThread;
import com.portnexus.websocket.WebSocketClient;
import com.portnexus.proximity.AppActivity;
import android.widget.ImageView;

public class AppService extends Service {
    private static final int MAX_NUM_EVENTS = 100;
    private LinkedList<GimbalEvent> events;
    private PlaceEventListener placeEventListener;
    private CommunicationListener communicationListener;

	public String WEBSOCKET_PROD_URL = "wss://barnyard.mobileassociate.com:443/spsedictation/safecomm";
	String websocketUrl = null;
	
    WebSocketClient webSocketclient;  // The websocket client
    ReconnectSocketThread aReconnectSocketThread = new ReconnectSocketThread();  // This will reconnect the socket if the connection drops
	PingSocketThread aPingSocketThread = new PingSocketThread();

	AppService me = this;
	
    @Override
    public void onCreate() {
        events = new LinkedList<GimbalEvent>(GimbalDAO.getEvents(getApplicationContext()));

        Gimbal.setApiKey(this.getApplication(), "921ab13d-909e-46de-8b1d-0ebdf1b43267");
       
        // Setup PlaceEventListener
        placeEventListener = new PlaceEventListener() {
            @Override
            public void onEntry(Place place, long timestamp) {
            	//Log.i("tag", "placeEventListener::onEntry");
        		if (! Build.MODEL.equals("SAMSUNG-SGH-I337")) {
        			sendDogLocated();
        		} else {
        			AppActivity.me.runOnUiThread(new Runnable() {
        			    @Override
        			    public void run() {
        			    	AppActivity.imageView = (ImageView) AppActivity.me.findViewById(R.id.imageView1);
               			 
                			AppActivity.imageView.setImageResource(R.drawable.dog_happy);
                			AppActivity.imageView.invalidate();
                		
        			    }
        			});
        		}
            	
                addEvent(new GimbalEvent(TYPE.PLACE_ENTER, place.getName(), new Date(timestamp)));
            }

            @Override
            public void onExit(Place place, long entryTimestamp, long exitTimestamp) {
            	//Log.i("tag", "placeEventListener::onExit");
        		if (Build.MODEL.equals("SAMSUNG-SGH-I337")) {
        			sendDogLost();
        			
        			AppActivity.me.runOnUiThread(new Runnable() {
        			    @Override
        			    public void run() {
        			    	AppActivity.imageView = (ImageView) AppActivity.me.findViewById(R.id.imageView1);
               			 
                			AppActivity.imageView.setImageResource(R.drawable.dog_running);
                			AppActivity.imageView.invalidate();
        			    }
        			});
        			
        			}
        		
                addEvent(new GimbalEvent(TYPE.PLACE_EXIT, place.getName(), new Date(exitTimestamp)));
            }
        };
        
        PlaceManager.getInstance().addPlaceEventListener(placeEventListener);
        
        // Setup CommunicationListener
        communicationListener = new CommunicationListener() {
            @Override
            public void communicationsOnPlaceEntry(Collection<Communication> communications, Place place, long timestamp) {
                for (Communication comm : communications) {
                	//Log.i("tag", "commPlaceEntry:onEntry");
                    
                    addEvent(new GimbalEvent(TYPE.COMMUNICATION_ENTER, comm.getTitle(), new Date(timestamp)));
                }
            }

            @Override
            public void communicationsOnPlaceExit(Collection<Communication> communications, Place place, long entryTimestamp, long exitTimestamp) {
                for (Communication comm : communications) {
                	//Log.i("tag", "commPlaceEntry:onExit");
                    
                    addEvent(new GimbalEvent(TYPE.COMMUNICATION_EXIT, comm.getTitle(), new Date(exitTimestamp)));
                }
            }

            @Override
            public void communicationFromPush(Communication communication) {
                addEvent(new GimbalEvent(TYPE.COMMUNICATION_PUSH, communication.getTitle(), new Date()));
            }
        };
        CommunicationManager.getInstance().addListener(communicationListener);
        
        // Start ping and reconnect
  		aReconnectSocketThread.start();  // This will also do the initial connect to the websocket
  		aPingSocketThread.start();

 
    }

    private void addEvent(GimbalEvent event) {
        while (events.size() >= MAX_NUM_EVENTS) {
            events.removeLast();
        }
        events.add(0, event);
        GimbalDAO.setEvents(getApplicationContext(), events);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        PlaceManager.getInstance().removePlaceEventListener(placeEventListener);
        CommunicationManager.getInstance().removeListener(communicationListener);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
	/*
	 * createWebSocket
	 * Create the web socket
	 */
	public void connectWebSocket() {
        log("connectWebSocket");
        
		// Setup the URL
        websocketUrl = WEBSOCKET_PROD_URL;
		
		log("Create Web Socket url=" + websocketUrl);
		
		// Create The web socket
		webSocketclient = new WebSocketClient(URI.create(websocketUrl), new WebSocketClient.Listener() {
		    @Override
		    public void onConnect() {
		        log("Socket Connected!");
		        
		        // Send the register command to the socket server
		        try {
		        	// Make sure that the phone number can be read
	        		// Keep retrying, if phone number is null
	        		int i = 0;
	        		String myPhoneNumber = getMyPhoneNumber();
	        		while (myPhoneNumber == null && i < 10) {
				        log("Phone number is null. Sleep and retry");
				        myPhoneNumber = getMyPhoneNumber() ;
				        Thread.sleep(10000);
				        i++;
	        		}
	        		if (myPhoneNumber != null) {
				        	log("Register Phone: " + myPhoneNumber);
			        		String registerCommand = String.format("<sc op='R'><phone>%s</phone><d>A</d></sc>", myPhoneNumber);
			        		webSocketclient.send(registerCommand);
					        log("Socket is Registered");
					        
					        // Register interest in dog loc
					        registerInterestInDogLocation();
					        registerInterestInDogLost();
					        
					        // TESt
					        //sendDogLocated();
	        		} else {
				        log("Did not register. Phone is null.");
	        		}
		        } catch(Exception ex) {
		        	log("onConnect Exception: " + ex.getMessage());
		        }
		    }

		    @Override
		    public void onMessage(String message) {
		        log(String.format("Got string message! %s", message));
		        
		        // Parse the dog message - dog is missing.
		        // This is received by the Crowd Source - start looking for dog.
		        if (message.contains("<doglost>")) {
		        	// Get the proximity of the dog.
		        	// Send a <dogloc> when proximity is found
		        } else if (message.contains("<dogloc>")) {
		        	// dog located. Diplay lat/lon
		        }
		        
		    }

		    @Override
		    public void onMessage(byte[] data) {
		        log(String.format("Got binary message! "));
		    }

		    @Override
		    public void onDisconnect(int code, String reason) {
		        log(String.format("Disconnected! Code: %d Reason: %s", code, reason));
		       
		        // Attempt to reconnect
		        webSocketclient = null;
		        synchronized(aReconnectSocketThread.connectLockObject){
			        aReconnectSocketThread.connectLockObject.notifyAll();
		        }
		    }

		    @Override
		    public void onError(Exception error) {
		        log("Error! " +  error.getMessage());
		        
		        //Attempt To reconnect
		        webSocketclient = null;
		        synchronized(aReconnectSocketThread.connectLockObject){
			        aReconnectSocketThread.connectLockObject.notifyAll();
		        }
		    }

		}, null);

		// Now connect the web socket
		log("Attempt to connect web socket");
		
		// Setup a trust manager that allows all certs
		X509TrustManager[] trustManagers = new X509TrustManager[]{new X509TrustManager(){ 
          public void checkClientTrusted(X509Certificate[] chain, 
                          String authType) throws CertificateException {} 
          public void checkServerTrusted(X509Certificate[] chain, 
                          String authType) throws CertificateException {} 
          public X509Certificate[] getAcceptedIssuers() { 
                  return new X509Certificate[0]; 
          }}};
          
		WebSocketClient.setTrustManagers(trustManagers);
		
		// Connect the socket
		if (webSocketclient != null)
			webSocketclient.connect();
	}
	
	
	public String getMyPhoneNumber() { 
		if (Build.MODEL.equals("SAMSUNG-SGH-I337")) {
			return "2145551111";
		} else {
			return "2145552222";
		}
	}


	public void log(String aString) {
			Log.i("ATTDriveTest", aString);		
	}
	
	// Owner sends this
	public void sendDogLost() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='doglost'>");
				sb.append("</sc>");
        				
				log("Dog Lost");
				
				webSocketclient.send(sb.toString());
				
			} catch(Exception ex) {
			}
		}
	}
	
	public void registerInterestInDogLocation() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='IC'><opcode>dogloc</opcode></sc>");
				webSocketclient.send(sb.toString());
				log("Dog Located registered");
			} catch(Exception ex) {
				log(ex.getMessage());
			}
		}
		
	}
	
	public void registerInterestInDogLost() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='IC'><opcode>doglost</opcode></sc>");
				webSocketclient.send(sb.toString());
				log("Dog Lost registered");
				
			} catch(Exception ex) {
				log(ex.getMessage());
			}
		}
		
	}
	
	public void sendDogLocated() {
		if (webSocketclient != null) {
			try {
        		StringBuilder sb = new StringBuilder();
				sb.append("<sc op='dogloc'>");
				sb.append("<lat>").append("36.113932").append("</lat>");  
				sb.append("<lon>").append("-115.197266").append("</lon>");  
				sb.append("</sc>");
        				
				log("Dog Lost");
				
				webSocketclient.send(sb.toString());
				
			} catch(Exception ex) {
			}
		}

	}
		
	
	// Connect Web Socket Thread
	public  class ReconnectSocketThread extends Thread {
		public final Object connectLockObject = new Object();
		public boolean stopThread = false;
		   
		@Override 
		public void run() {
			// Do an initial sleep. While the phone is rebooting we need time so that the carrier connects
//			try {
//				Thread.sleep(120000);
//			} catch (InterruptedException e) {
//			}

			while (!stopThread) {
				// Wait until the websocket has become null.
				// After the socket becomes null then try to reconnected the web socket
				synchronized(connectLockObject){
				    while (webSocketclient != null){
				    	try {
							connectLockObject.wait();
						} catch (InterruptedException e) {
						}
				    }
				}
				
				// webSocket is null. Reconnect to the websocket
				try {
					if (!stopThread)
						me.connectWebSocket();
				} catch(Exception ex) {
				}
				
				// If the user is out of data coverage then we will get into a reconnect loop. So sleep for a while
				try {
					Thread.sleep(120000);
				} catch (InterruptedException e) {
				}
			}
		}
	}
	
	// Socket Ping Thread.
	// Ping the server.
	public  class PingSocketThread extends Thread {
		public boolean stopThread = false;
		
		@Override 
		public void run() {
			while (!stopThread) {
				if (webSocketclient != null && webSocketclient.isConnected()) {
					// Send the ping
					try {
						webSocketclient.send("<sc op='P'/>");
					} catch(Exception ex) {
						log("Socket ping Exception: " + ex.getMessage());
					}
				}
				try {
					Thread.sleep(240000);
				} catch(Exception ex) {
				}
			}
		}
	}




}
